/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;



/**
 *
 * @author hifi
 */
public class MessageStorage {
  private static final String FILE_PATH =
            System.getProperty("user.home") + "/RMQuickChat/data/messages.json";
    private static final Gson gson = new Gson();

    // === Save all messages to file ===
    public static void saveMessages(List<Message> messages) {
        if (messages == null) messages = new ArrayList<>();
        try {
            File file = new File(FILE_PATH);
            File parentDir = file.getParentFile();
            if (!parentDir.exists()) parentDir.mkdirs();

            try (Writer writer = new FileWriter(file)) {
                gson.toJson(messages, writer);
            }
            System.out.println("✅ Messages saved successfully to " + FILE_PATH);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                    "❌ Failed to save messages: " + e.getMessage(),
                    "Save Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // === Load all messages from file ===
    public static List<Message> loadMessages() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            System.out.println("⚠ No previous messages found.");
            return new ArrayList<>();
        }

        try (Reader reader = new FileReader(file)) {
            Type listType = new TypeToken<ArrayList<Message>>() {}.getType();
            List<Message> messages = gson.fromJson(reader, listType);
            if (messages == null) return new ArrayList<>();
            return messages;
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // === Delete a specific message by ID ===
    public static boolean deleteMessage(String messageId) {
        List<Message> messages = loadMessages();
        boolean removed = false;

        Iterator<Message> iterator = messages.iterator();
        while (iterator.hasNext()) {
            Message msg = iterator.next();
            if (msg.getMessageId().equals(messageId)) {
                iterator.remove();
                removed = true;
                break;
            }
        }

        if (removed) {
            saveMessages(messages);
            JOptionPane.showMessageDialog(null,
                    "🗑 Message deleted successfully.",
                    "Delete Message", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                    "⚠ Message not found.",
                    "Delete Failed", JOptionPane.WARNING_MESSAGE);
        }
        return removed;
    }

    // === Update a message (e.g., mark stored message as sent) ===
    public static boolean updateMessageStatus(String messageId, Message.Status newStatus) {
        List<Message> messages = loadMessages();
        boolean updated = false;

        for (Message msg : messages) {
            if (msg.getMessageId().equals(messageId)) {
                msg.setStatus(newStatus);
                updated = true;
                break;
            }
        }

        if (updated) {
            saveMessages(messages);
            JOptionPane.showMessageDialog(null,
                    "✅ Message status updated to " + newStatus + ".",
                    "Update Successful", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                    "⚠ Message not found.",
                    "Update Failed", JOptionPane.WARNING_MESSAGE);
        }
        return updated;
    }

    // === Helper: Clear all messages (for admin/test use) ===
    public static void clearAllMessages() {
        saveMessages(new ArrayList<>());
        JOptionPane.showMessageDialog(null,
                "🧹 All messages cleared.",
                "Clear Storage", JOptionPane.INFORMATION_MESSAGE);
    }
}