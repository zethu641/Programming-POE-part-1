/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author hifi
 */
public class Message {

    Message(String string, int i, String string0, String hi_Keegan_did_you_receive_the_payment) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public enum Status { SENT, DISREGARDED, STORED }

    private String messageId;       // 10-digit string
    private int messageNumber;      // 0-based index of the message
    private String recipient;       // recipient phone number
    private String messageText;     // message content
    private String messageHash;     // auto-generated hash
    private Status status;

    // === Constructors ===
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageId = generateMessageId();
        this.messageHash = createMessageHash();
        this.status = Status.STORED; // default to stored when created
    }

    public Message(String messageId, int messageNumber, String recipient, String messageText, Status status) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageId = messageId;
        this.messageHash = createMessageHash();
        this.status = status == null ? Status.STORED : status;
    }

    // === ID, Validation, and Hash ===
    public static String generateMessageId() {
        Random rnd = new Random();
        long v = Math.abs(rnd.nextLong()) % 1_000_000_0000L;
        return String.format("%010d", v);
    }

    public boolean checkMessageID() {
        return this.messageId != null && this.messageId.matches("\\d{10}");
    }

    public boolean checkRecipientCell() {
        return this.recipient != null && this.recipient.matches("^\\+27\\d{9}$");
    }

    public String createMessageHash() {
        String firstTwo = this.messageId != null && this.messageId.length() >= 2
                ? this.messageId.substring(0, 2) : "00";
        String combined = "";
        if (this.messageText != null && !this.messageText.trim().isEmpty()) {
            String[] parts = this.messageText.trim().split("\\s+");
            String first = parts.length > 0 ? parts[0].replaceAll("[^A-Za-z0-9]", "") : "";
            String last = parts.length > 0 ? parts[parts.length - 1].replaceAll("[^A-Za-z0-9]", "") : "";
            combined = (first + last).toUpperCase();
        }
        return String.format("%s:%d:%s", firstTwo, this.messageNumber, combined);
    }

    // === Message Logic ===
    public static String validateMessageLength(String text) {
        if (text == null) text = "";
        int len = text.length();
        if (len <= 250) return "Message ready to send.";
        int excess = len - 250;
        return String.format("Message exceeds 250 characters by %d, please reduce size.", excess);
    }

    public String performAction(int actionCode) {
        switch (actionCode) {
            case 0:
                this.status = Status.SENT;
                return "Message successfully sent.";
            case 1:
                this.status = Status.DISREGARDED;
                return "Message disregarded.";
            case 2:
                this.status = Status.STORED;
                return "Message stored for later.";
            default:
                return "Unknown action.";
        }
    }

    public String sendMessageViaDialog() {
        Object[] options = {"Send message", "Disregard Message", "Store Message"};
        int choice = JOptionPane.showOptionDialog(null,
                "Choose what to do with the message:",
                "Message Options",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]);
        return performAction(choice);
    }

    // === Printing ===
    public String printMessageDetails() {
        return String.format("Message ID: %s\nRecipient: %s\nMessage: %s\nStatus: %s",
                this.messageId, this.recipient, this.messageText,
                this.status == null ? "UNKNOWN" : this.status);
    }

    public static int returnTotalMessages(List<Message> list) {
        if (list == null) return 0;
        int count = 0;
        for (Message m : list)
            if (m.status == Status.SENT)
                count++;
        return count;
    }

    public static String printMessages(List<Message> list) {
        if (list == null || list.isEmpty()) return "No messages.";
        StringBuilder sb = new StringBuilder();
        for (Message m : list) {
            sb.append(m.printMessageDetails());
            sb.append("\n-----------------\n");
        }
        return sb.toString();
    }

    // === Getters & Setters ===
    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public Status getStatus() { return status; }

    public void setStatus(Status status) { this.status = status; }

    public boolean isSent() {
        return this.status == Status.SENT;
    }

    public boolean isStored() {
        return this.status == Status.STORED;
    }
}
