/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;



/**
 *
 * @author hifi
 */
public class ChatAppGUI {
     public static void main(String[] args) {
        login login = new login();

           // === Apply custom colours to all pop-ups ===
        Color pinkBg = Color.decode("#FFC0CB");      // soft pink background
        Color whiteText = Color.WHITE;               // white text
        Color blackBorder = Color.BLACK;             // black border

        UIManager.put("OptionPane.background", pinkBg);
        UIManager.put("Panel.background", pinkBg);
        UIManager.put("OptionPane.messageForeground", whiteText);
        UIManager.put("OptionPane.border", new LineBorder(blackBorder, 3));

        // === Registration loop ===
        while (true) {
            JOptionPane.showMessageDialog(
                    null,
                    "*** New User Sign-Up ***\nProvide the requested details to create your account.",
                    "Sign-Up",
                    JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                    null,
                    "Pick a username (must include '_' and be 5 characters or fewer):",
                    "Username",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return; // user cancelled

            String password = JOptionPane.showInputDialog(
                    null,
                    "Set a password (at least 8 characters, with a capital letter, a number, and a special character):",
                    "Password",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(
                    null,
                    "Enter your cellphone number with the international code (for example: ‪+27838968976‬):",
                    "Cellphone",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(
                    null,
                    regMessage,
                    "Sign-Up Result",
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (regMessage.equals("Registration successful.")) {
                break; // move on to login
            }
            // otherwise loop again until details are valid
        }

        // === Login loop ===
        while (true) {
            JOptionPane.showMessageDialog(
                    null,
                    "*** Account Login ***\nEnter your credentials to continue.",
                    "Login",
                    JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                    null,
                    "Username:",
                    "Login",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return;

            String password = JOptionPane.showInputDialog(
                    null,
                    "Password:",
                    "Login",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());

            JOptionPane.showMessageDialog(
                    null,
                    msg,
                    ok ? "Login Successful" : "Login Failed",
                    ok ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
            );

            if (ok) {
                break; // finish after successful login
            }
            // repeat until correct
        }
    }
}