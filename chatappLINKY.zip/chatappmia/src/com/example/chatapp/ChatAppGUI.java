/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;




/**
 *
 * @author hifi
 */
public class ChatAppGUI {
       public static void main(String[] args) {
        // Set up global UI defaults
        Color purple = new Color(128, 0, 128);
        Color pink = new Color(255, 105, 180);
        Color white = Color.WHITE;

        UIManager.put("OptionPane.background", purple);
        UIManager.put("Panel.background", purple);
        UIManager.put("OptionPane.messageForeground", white);
        UIManager.put("OptionPane.border", new LineBorder(pink, 4));
        UIManager.put("Button.background", white);
        UIManager.put("Button.foreground", Color.BLACK);

        // Show logo + slogan popup (not a separate frame)
        showLogoPopup();

        login login = new login();

        // === REGISTRATION ===
        while (true) {
            JOptionPane.showMessageDialog(null,
                    "✨ Create your QuickChat profile below! ✨\nLet's get you set up.");

            String username = JOptionPane.showInputDialog(null,
                    "Choose a username (include '_' and max 5 characters):");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null,
                    "Create a password (8+ chars, 1 capital, 1 number, 1 symbol):");
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(null,
                    "Enter your cellphone (e.g. ‪+27838968976‬):");
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(null, regMessage);

            if (regMessage.equals("Registration successful.")) break;
        }

        // === LOGIN ===
        boolean loggedIn = false;
        String loggedUsername = null;
        while (!loggedIn) {
            JOptionPane.showMessageDialog(null, "💬 Log into your QuickChat account");

            String username = JOptionPane.showInputDialog(null, "Username:");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "Password:");
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());
            JOptionPane.showMessageDialog(null, msg);

            if (ok) {
                loggedIn = true;
                loggedUsername = username.trim();
            }
        }

        JOptionPane.showMessageDialog(null,
                "🌟 Welcome to LZQuickChat! 🌟\n“Where every message connects hearts.”");

        // === NUMBER OF MESSAGES ===
        int messagesToEnter = 0;
        while (messagesToEnter <= 0) {
            String nm = JOptionPane.showInputDialog(null, "How many messages would you like to send today?");
            if (nm == null) return;
            try {
                messagesToEnter = Integer.parseInt(nm.trim());
                if (messagesToEnter <= 0)
                    JOptionPane.showMessageDialog(null, "Please enter a positive number.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }

        List<Message> allMessages = new ArrayList<>();
        boolean quit = false;
        int sentCount = 0;

        while (!quit) {
            String menu = "📱 Choose what you'd like to do:\n"
                    + "1️⃣ Send messages\n"
                    + "2️⃣ View recent messages\n"
                    + "3️⃣ Exit app";
            String choice = JOptionPane.showInputDialog(null, menu);
            if (choice == null) return;

            switch (choice.trim()) {
                case "1":
                    if (sentCount >= messagesToEnter) {
                        JOptionPane.showMessageDialog(null,
                                "You've already sent all your planned messages. 🎯\nCome back later to send more!");
                        break;
                    }

                    for (int i = sentCount; i < messagesToEnter; i++) {
                        String recipient = JOptionPane.showInputDialog(null,
                                String.format("Enter recipient for message %d (e.g. +27...):", i + 1));
                        if (recipient == null) break;

                        String messageText = JOptionPane.showInputDialog(null,
                                "Type your message (max 250 characters):");
                        if (messageText == null) break;

                        if (messageText.length() > 250) {
                            JOptionPane.showMessageDialog(null,
                                    "⚠ Message too long! Please shorten it to 250 characters.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            i--;
                            continue;
                        }

                        JOptionPane.showMessageDialog(null, "📨 Sending message...");

                        Message m = new Message(allMessages.size(), recipient.trim(), messageText);
                        String actionResult = m.sendMessageViaDialog();
                        JOptionPane.showMessageDialog(null, actionResult);

                        if (m.getStatus() == Message.Status.STORED) {
                            try {
                                Message.storeMessagesToJson(
                                        Collections.singletonList(m),
                                        System.getProperty("user.home") + "/stored_messages.json");
                                JOptionPane.showMessageDialog(null,
                                        "✅ Message saved to JSON at " + System.getProperty("user.home") + "/stored_messages.json");
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(null, "❌ Failed to store message: " + ex.getMessage());
                            }
                        }

                        JOptionPane.showMessageDialog(null, m.printMessageDetails());
                        allMessages.add(m);
                        sentCount++;

                        if (sentCount >= messagesToEnter) {
                            JOptionPane.showMessageDialog(null, "🎉 You've sent all your messages!");
                            break;
                        }
                    }

                    int totalSent = Message.returnTotalMessages(allMessages);
                    JOptionPane.showMessageDialog(null, "📊 Total messages sent so far: " + totalSent);
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null,
                            "🕓 Message history feature coming soon!");
                    break;

                case "3":
                    quit = true;
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "❌ Invalid choice. Please pick 1, 2, or 3.");
            }
        }

        JOptionPane.showMessageDialog(null,
                "💜 Thank you for using LZQuickChat!\nStay connected. Stay inspired.\n\nGoodbye!");
    }

    private static void showLogoPopup() {
        JLabel logoLabel = new JLabel("<html><center><h1 style='color:white;'>LZQuickChat</h1>"
                + "<p style='color:white;'>Connecting hearts, one chat at a time 💫</p></center></html>",
                SwingConstants.CENTER);

        logoLabel.setFont(new Font("Arial", Font.BOLD, 20));

        JOptionPane.showMessageDialog(null, logoLabel,
                "Welcome to LZQuickChat", JOptionPane.INFORMATION_MESSAGE);
    }
}