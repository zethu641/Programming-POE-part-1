package com.example.chatapp;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests for Message class (matches updated Message.java with getId/getHash/getContent/getSender).
 */
public class messageTest {

    public messageTest() {}

    @BeforeClass
    public static void setUpClass() {}

    @AfterClass
    public static void tearDownClass() {}

    @Before
    public void setUp() {}

    @After
    public void tearDown() {}

    // -----------------------------------------------------
    @Test
    public void testValidateMessageLength_success() {
        String msg = "Short message";
        assertEquals("Message ready to send.", Message.validateMessageLength(msg));
    }

    @Test
    public void testValidateMessageLength_failure() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 260; i++) sb.append("a");
        String longMsg = sb.toString();

        // Matches validateMessageLength in your Message.java (note no "please reduce size." phrase)
        assertEquals("Message exceeds 250 characters by 10.", Message.validateMessageLength(longMsg));
    }

    // -----------------------------------------------------
    @Test
    public void testRecipientNumberIncorrectFormat() {
        // Using the constructor present in your Message.java: Message(int number, String sender, String recipient, String content)
        Message m = new Message(0, "You", "08575975889", "Hi, test");
        assertFalse("Should be invalid SA number (missing +27)", m.checkRecipientCell());
    }

    // -----------------------------------------------------
    @Test
    public void testMessageHash() {
        // Use the 6-arg constructor so messageId is deterministic
        String cleanRecipient = "‪+27718693002‬";
        Message m = new Message(
                "0012345678", // id -> firstTwo = "00"
                0,            // number
                "You",        // sender
                cleanRecipient,
                "Hi Mike, can you join us for dinner tonight?",
                Message.Status.STORED
        );

        // According to createMessageHash: firstTwo : number : FIRSTWORD+LASTWORD uppercased
        String expected = "00:0:HITONIGHT";
        assertEquals(expected, m.getHash());
    }

    // -----------------------------------------------------
    @Test
    public void testMessageIdGenerated() {
        String id = Message.generateMessageId();
        assertNotNull(id);
        assertEquals(10, id.length());
        assertTrue(id.matches("\\d{10}"));
    }

    // -----------------------------------------------------
    @Test
    public void testPerformActionVariants() {
        Message m1 = new Message(0, "You", "‪+27718693002‬", "Msg");
        assertEquals("Message successfully sent.", m1.performAction(0));
        assertEquals(Message.Status.SENT, m1.getStatus());

        Message m2 = new Message(1, "You", "‪+27718693002‬", "Msg2");
        assertEquals("Message disregarded.", m2.performAction(1));
        assertEquals(Message.Status.DISREGARDED, m2.getStatus());

        Message m3 = new Message(2, "You", "‪+27718693002‬", "Msg3");
        assertEquals("Message stored for later.", m3.performAction(2));
        assertEquals(Message.Status.STORED, m3.getStatus());
    }
}