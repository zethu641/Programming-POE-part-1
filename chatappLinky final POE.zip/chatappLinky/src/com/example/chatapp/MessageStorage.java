/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Handles saving, loading, and updating stored messages.
 * Updated to match the new message structure (ID + Hash).
 */
public class MessageStorage {

    private static final String FILE_PATH =
            System.getProperty("user.home") + "/RMQuickChat/data/messages.json";

    private static final Gson gson = new Gson();

    // =============================
    // Save all messages to JSON file
    // =============================
    public static void saveMessages(List<Message> messages) {
        if (messages == null) messages = new ArrayList<>();
        try {
            File file = new File(FILE_PATH);
            File parentDir = file.getParentFile();

            if (!parentDir.exists()) parentDir.mkdirs();

            try (Writer writer = new FileWriter(file)) {
                gson.toJson(messages, writer);
            }

            System.out.println("✔ Messages saved to: " + FILE_PATH);

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("❌ Failed to save messages: " + e.getMessage());
        }
    }

    // =============================
    // Load all messages from JSON file
    // =============================
    public static List<Message> loadMessages() {
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            System.out.println("⚠ No stored messages found.");
            return new ArrayList<>();
        }

        try (Reader reader = new FileReader(file)) {

            Type listType = new TypeToken<ArrayList<Message>>(){}.getType();
            List<Message> messages = gson.fromJson(reader, listType);

            return messages != null ? messages : new ArrayList<>();

        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    // =============================
    // Delete a message by HASH (updated)
    // =============================
    public static boolean deleteMessageByHash(String hash) {

        List<Message> messages = loadMessages();
        boolean removed = false;

        Iterator<Message> iterator = messages.iterator();
        while (iterator.hasNext()) {
            Message msg = iterator.next();

            // NEW → match message hash
            if (msg.getHash().equals(hash)) {
                iterator.remove();
                removed = true;
                break;
            }
        }

        if (removed) {
            saveMessages(messages);
            System.out.println("🗑 Deleted message with hash: " + hash);
        } else {
            System.out.println("⚠ Message with hash " + hash + " not found.");
        }
        return removed;
    }

    // =============================
    // Delete a message by ID (kept for compatibility)
    // =============================
    public static boolean deleteMessageById(String messageId) {

        List<Message> messages = loadMessages();
        boolean removed = false;

        Iterator<Message> iterator = messages.iterator();
        while (iterator.hasNext()) {
            Message msg = iterator.next();

            // Updated to match new field name: getId()
            if (msg.getId().equals(messageId)) {
                iterator.remove();
                removed = true;
                break;
            }
        }

        if (removed) {
            saveMessages(messages);
            System.out.println("🗑 Deleted message with ID: " + messageId);
        } else {
            System.out.println("⚠ Message ID not found: " + messageId);
        }
        return removed;
    }

    // =============================
    // Clear all messages (Admin/Test)
    // =============================
    public static void clearAllMessages() {
        saveMessages(new ArrayList<>());
        System.out.println("🧹 All stored messages cleared.");
    }
}